package dao;

import bean.BankBean;

public interface BankDaoI {

	public BankBean checkAccount(long accNo);

	public void setData(long accNo, BankBean bean);

}
