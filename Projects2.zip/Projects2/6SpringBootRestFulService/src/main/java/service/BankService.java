package service;

import java.util.List;

import entities.BankEntity;
import entities.TransactionEntity;
import exception.BankException;

public interface BankService {

	public BankEntity createAccount(BankEntity bank) throws BankException;

	public BankEntity accountsDetails(Long accNo) throws BankException;

	public Double showBalance(Long accNo) throws BankException;

	public Double deposit(Long accNo, Double amt) throws BankException;

	public Double withdraw(Long accNo, Double amt) throws BankException;

	public Double fundTransfer(Long accNo1, Double amt, Long accNo2) throws BankException;

	public List<TransactionEntity> printTransaction(Long accNo) throws BankException;

}
