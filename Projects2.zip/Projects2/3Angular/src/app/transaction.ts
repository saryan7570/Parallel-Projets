export class Transaction {
    transactionId : number;
    tranType : String;
    tranBalance : number;
    accountNum : number;
    constructor(transactionId: number, tranType:String, tranBalance: number, accountNumber:number){
        this.transactionId = transactionId;
        this.tranType = tranType;
        this.tranBalance = tranBalance;
        this.accountNum = accountNumber;
    }
}
